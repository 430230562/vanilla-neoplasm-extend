//其他模组物品引用，如果是建筑的话就是把item换成block
const name = Vars.content.item("mod-name")

//更改原版效果的反应
let scope = new Packages.rhino.TopLevel();
new Packages.rhino.ClassCache().associate(scope);
let n = new Packages.rhino.NativeJavaObject(scope, StatusEffects.burning, StatusEffect, true)

n.affinity(StatusEffects.shocked, (unit, result, time) => {})

//打印文字
Vars.ui.showLabel("txt", 0.01, this.x, this.y);

Vars.tree.loadSound(soundName)
//可以加载mod的音效

Vars.world.tile(link)//可以获取位置id为int的地板

Angles.trnsx(旋转角, x, y);
Angles.trnsy(旋转角, x, y);//用于计算旋转后的位置

Mathf.chance(true的概率)
Mathf.range(波动范围);//结果从波动范围 到 -波动范围

Units.nearby(队伍,x,y,范围,other => {})//遍历范围内单位
Units.nearbyEnemies(队伍,x,y,范围,other => {})//

Units.nearbyBuildings(x,y,范围,b => {})//遍历范围内建筑
Vars.indexer.eachBlock(unit,range,b => {})

Vars.state.rules.unitHealth(unit.team)//单位血量倍数

var seq = Groups.bullet.intersect(x,y,宽，高)//遍历范围内子弹
seq.each(b => {})

Time.time//游戏时间
i += Time.delta//计时器
let timer = new Interval();//计时器
timer.get(reload)//时间到reload为时间

Core.atlas.find("bugs-gredizion"))//获取贴图
Core.bundle.get("report-1")//从bundles里找文本
Core.app.openURI("https://430230562.github.io/zerg")//打开网站

Vars.state.teams.cores(tile.team()).size//核心数量
Vars.ui.showLabel(显示文本, 0.01, this.x, this.y);

//物品
build.items.add(物品, 数量);//建筑加物品
build.items.remove(物品, 数量);//建筑减物品
build.items.get(Items.copper);//建筑物品量

//液体
build.liquids.add(物品, 数量);//建筑加液体
build.liquids.remove(物品, 数量);//建筑减液体
build.liquids.get(Liquids.water)//建筑液体量

team.core()//某队的核心

Core.app.exit()//退游

bullet.create(this,队伍,x,y,旋转角度)//生成子弹

//tile
this.tile.circle(范围, cons(tile => {}))//查找范围内的地块,并保存在tile中
tile.block()//地块上的建筑
tile.setBlock(建筑,队伍)//设置地块上的建筑,Team.sharded为黄队
tile.setAir();//清除地块上的建筑
tile.setFloor(地板);//设置地板

Vars.world.tile(tileX,tileY)//指定坐标地块

Puddles.deposit(tile, liquid, amount * scaling);//地板上生成液体

//payload
function Pay(block) {
	return new BuildPayload(block, Team.derelict)
}//生成建筑的载荷
Pay().update(null,this);//开更新
Pay().build.acceptItem(this, item)//可接受物品
Pay().build.handleItem(this, item);//加入物品
Pay().set(x,y,旋转角度)//设置载荷位置
Pay().draw()//画出载荷

build.applyBoost(倍速,时间)

//unit
unit.spawn(队伍,x,y)

heal(治疗量)

damagePierce(伤害量)//无视护甲
damage(伤害量)//不无视护甲

apply(效果,时间)//给单位效果

Fires.create(unit.tileOn())//放火

//子弹
collision(other, x, y)//击中

//draw
Lines.arc(x,y,范围,0.15/*应该是线宽*/,旋转角度);
Draw.rect(贴图,x,y,旋转角度)

//bullet
hitEntity(b, entity, health){
    this.super$hitEntity(b, entity, health);
    if(entity instanceof Unit) {
        var unit = entity;
    }
},//击中单位